function openNav() {
    document.getElementById("Nav").style.width = "100%";
}

function closeNav() {
    document.getElementById("Nav").style.width = "0%";
}

function openMobNav() {
    document.getElementById("MobNav").style.height = "100%";
}

function closeMobNav() {
    document.getElementById("MobNav").style.height = "0%";
}

function rotate() {
    document.getElementById("rot").style.transform = "rotate(7turn)"
}



